sh pfaffianmethod.sh
sh exactdiag.sh
sh explicitproj.sh

echo 'Explicit Projection'
cd j7wm0files
echo 'w/G = 0'
python ../explicit.py j7_wm0_ss.in ../j7_wm0_ss_explicit.dat

cd ../j7wm3files
echo 'w/G = 0.3'
python ../explicit.py j7_wm3_ss.in ../j7_wm3_ss_explicit.dat

cd ../j7wm7files
echo 'w/G = 0.7'
python ../explicit.py j7_wm7_ss.in ../j7_wm7_ss_explicit.dat

cd ../j7wm15files
echo 'w/G = 1.5'
python ../explicit.py j7_wm15_ss.in ../j7_wm15_ss_explicit.dat

cd ../
mv j7*.dat ../plots/
echo 'Pfaffian Method'

echo 'w/G = 0'
cd j7wm0files
python ../projpf.py j7_wm0_ss.in ../j7_wm0_ss_pf.dat

echo 'w/G = 0.3'
cd ../j7wm3files
python ../projpf.py j7_wm3_ss.in ../j7_wm3_ss_pf.dat

echo 'w/G = 0.7'
cd ../j7wm7files
python ../projpf.py j7_wm7_ss.in ../j7_wm7_ss_pf.dat

echo 'w/G = 1.5'
cd ../j7wm15files
python ../projpf.py j7_wm15_ss.in ../j7_wm15_ss_pf.dat

cd ../
mv j7*.dat ../plots/
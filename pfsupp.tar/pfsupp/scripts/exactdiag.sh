echo 'Exact diagonalization'
echo 'w/G = 0'
python seniority.5.py 0 > ce0.out
python Ec_exact.py ce0.out j7wm0files/j7_wm0_ss.in > exactw0.out

echo 'w/G = 0.3'
python seniority.5.py .3 > ce3.out
python Ec_exact.py ce3.out j7wm3files/j7_wm3_ss.in > exactw3.out

echo 'w/G = 0.7'
python seniority.5.py .7 > ce7.out
python Ec_exact.py ce7.out j7wm7files/j7_wm7_ss.in > exactw7.out

echo 'w/G = 1.5'
python seniority.5.py 1.5 > ce15.out
python Ec_exact.py ce15.out j7wm15files/j7_wm15_ss.in > exactw15.out

mv exactw*.out ../plots
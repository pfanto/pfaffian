This directory contains the codes and data files to do particle-number projection explicitly and with the Pfaffian formula.  We include data files from the f_7/2 model described in the main text.  It also includes the codes necessary for the exact diagonalization.  To obtain the f_7/2 data, run

sh do_j7.sh

To run just the exact diagonalization code, run

sh exact.sh

The algorithm logpfaffian.py is adapted from M. Wimmer, Algorithm 923, ACM Trans. Math. Soft. 38, 30 (2012).  The exact diagonalization code seniority.5.py was provided by G.F. Bertsch.
This directory contains the codes and data files to do particle-number projection explicitly or with the Pfaffian formula.  We include data files from the f_7/2 model described in the main text.  To obtain the f_7/2 data, run

sh do_j7.sh

cd j7_wm3_ss_files
python ../proj.py ../j7_wm3_ss.in
python ../explicit.py ../j7_wm3_ss.in
mv j7_wm3_ss*.dat ../../plots/
cd ../
sh exact.sh
mv exactthermal.out ../plots/
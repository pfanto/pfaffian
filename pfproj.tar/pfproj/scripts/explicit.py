import numpy as np
import scipy.linalg as la
import scipy.misc
import sys
import matplotlib.pyplot as plt
import warnings
import time
"""
Particle-number projection in a single j-shell by explicit projection
Author: Paul Fanto
Last updated: 6/27/2017
Dependencies: numpy, scipy, matplotlib
Usage: python explicit.py <file with beta values>
Comment: This code assumes that the protons and neutron shells have the same j value.
This must be modified to extend the code beyond this assumption.
"""

# Filter warnings
warnings.filterwarnings("ignore","Casting complex values")

"""
Functions
"""
# Reads in relevant data from file of the form "prefix".b"beta value".mf
# Outputs energies and U and V matrices (in list form) for p,n.
# Also outputs the quasiparticle energy and p/n chemical potentials for this beta.
def hfbinput(beta,prefix):
	count = 0
	egc = -1.
	ep = np.array([])
	en = np.array([])
	up = np.array([])
	vp = np.array([])
	un = np.array([])
	vn = np.array([])
	chmp = -1.
	chmn = -1.

	# Format filename
	strbeta = '{0:4.7f}'.format(beta)
	if int(strbeta[-1]) == 5:
		x = int(strbeta[-2])
		if x > 5:
			x = x + 1
		strbeta = strbeta[:-2] + str(x)
	else:
		strbeta = strbeta[:-1]
	if int(strbeta[0]) == 0:
		strbeta = strbeta[1:]
	filename = prefix +'.b'+ strbeta + '.mf'

	# Find relevant sections in data file and extract data
	with open(filename) as f:
		for line in f:
			if line.find('HFB: zero-temperature') >= 1:
				data = next(f,None)
				e0 = float(data.split()[3])
			if line.find('Quasiparticle eigenenergies in HFB hamiltonian') >= 0:
				while True:
					data = next(f,None)
					if data is None:
						break
					sp = data.split()
					if data.find('Transformation') >= 0:
						break
					if data.find('Single Particle Matrices') >= 0:
						continue
					if data.find('U') == 1:
						count = count + 1
						continue
					if data.find('V') == 1:
						count = count + 1
						continue
					if data.find('Quasiparticle') >= 0:
						count = count + 1
						continue
					if count == 0:
						for i in range(0,len(sp)):
							ep = np.append(ep,float(sp[i]))
					elif count == 1:
						for i in range(0,len(sp)):
							en = np.append(en,float(sp[i]))
					elif count == 2:
						up = np.append(up,float(sp[len(sp)-1]))
					elif count == 3:
						vp = np.append(vp,float(sp[len(sp)-1]))
					elif count == 4:
						un = np.append(un,float(sp[len(sp)-1]))
					elif count == 5:
						vn = np.append(vn,float(sp[len(sp)-1]))
			if line.find('<H ') >= 1:
				egc = float(line.split()[3])
			if line.find('Chemical potential (proton ') >= 1:
				chmp = float(next(f,None))
			if line.find('Chemical potential (neutron') >= 1:
				chmn = float(next(f,None))
	return ep,en,up,vp,un,vn,egc,chmp,chmn

# Finds ground state energy from zero-temperature data file
def gndstate(prefix):
	e0 = -1
	filename = prefix +'.b' + '{0:4.6f}'.format(2000.) + '.mf'
	with open(filename) as f:
		for line in f:
			if line.find('<H ') >= 1:
				e0 = float(line.split()[3])
	return e0

# Numerical derivative. Includes endpoints.
def numDerivative(x,y):
	if len(x) != len(y):
		sys.stderr.write('Error: Derivative variables have unequal length')
		sys.exit(1)
	f = np.zeros(len(y))
	for i in range(0,len(y)-1):
		if i == 0:
			dx = x[1]-x[0]
			dy = y[1]-y[0]
			f[i] = dy/dx
		else:
			dx = x[i+1] - x[i-1]
			dy = y[i+1]-y[i-1]
			f[i] = dy/dx
	f[-1] = (y[-1]-y[-2])/(x[-1]-x[-2])
	return f

def choose(n,k):
	val = scipy.misc.factorial(n)/(scipy.misc.factorial(k)*scipy.misc.factorial(n-k))
	return val

def bin0(s):
    return str(s) if s<=1 else bin0(s>>1) + str(s&1)


def bin(s, L = 0):
    ss = bin0(s)
    if L > 0:
        return '0'*(L-len(ss)) + ss
    else:
        return ss


# check if nth bit is one
# & = bitwise AND operator
def isOne(x,n):
	if (x & (1<<n)):
		return True
	else:
		return False

# bitCount() counts the number of bits set (not an optimal function)
# toggleBit() returns an integer with the bit at 'offset' inverted, 0 -> 1 and 1 -> 0.

def toggleBit(int_type, offset):
	mask = 1 << offset
	return(int_type ^ mask)

def bitCount(int_type):
	""" Count bits set in integer """
	count = 0
	while(int_type):
		int_type &= int_type - 1
		count += 1
	return(count)

# Count the number of bits set before nth place
def setBefore(x,n):
	if n== 0: 
		return 0

	s = x & (2**n - 1)
	return bitCount(s)


def hamiltonian(states,E,W,Nsectors):
	ns = len(E) # dimension of single-particle space
	nstates = len(states) # dimension of many-particle space

	# Construct H_HFB matrix in quasiparticle basis
	Epsarr = np.zeros(2*ns)
	Epsarr[0:ns] = E; Epsarr[ns:2*ns] = -E
	Eps = np.diag(Epsarr)
	#pnice(Eps); sys.exit()
	Hmtx = np.dot(np.dot(W,Eps),W.T)

	K = np.zeros((nstates,nstates))
	"""
	Assuming that Hmtx is purely real:
	Hmtx = (h  Delta \\ - Delta  -h)
	K = 1/2 * (a^\dagger a ) Hmtx (a a^\dagger)^T + 1/2 tr(h)
	  = 1/2 \sum_ij h_ij (a_i^\dagger a_j - a_i a_j^\dagger) \Delta_ij a_i^\dagger a_j^\dagger - \Delta_ij a_i a_j) + 1/2 tr(h)
	  = \sum_ij	h_ij a_i^\dagger a_j + 1/2*\sum_ij Delta_ij (a_i^\dagger a_j^\dagger - a_i a_j)
	"""
	h = Hmtx[0:ns,0:ns] # Hartree-Fock Hamiltonian
	#pnice(h)
	Delta = Hmtx[0:ns,ns:2*ns] # HFB pairing field
	#pnice(Delta)
	#sys.exit()

	"""
	Construct part of K_ab due to h.
	h can couple states with the same number of particles only.
	"""
	# loop over allowed particle numbers 0,...,Ns+1
	index = 0
	for N in range(ns+1):
		# dimension of N-particle space
		dimN = Nsectors[N][0]
		# loop over indices a,b of many-particle basis states
		for a in range(index,index+dimN):
			for b in range(index,index+dimN):
				# if a = b, then only diagonal elements of h can couple them
				if a == b:
					state = states[a]
					for i in range(ns):
						if isOne(state,i):
							K[a,a] += h[i,i]
				# otherwise, check for all possible couplings.
				# creation and annihilation operators are represented as bit flips
				# s1 and s2 account for the phases that come from commutations
				else:
					a_state = states[a]
					b_state = states[b]
					for j in range(ns):
						if isOne(b_state,j):
							s1 = setBefore(b_state,j)
							bflip = toggleBit(b_state,j)
							for i in range(ns):
								if not isOne(bflip,i):
									if toggleBit(bflip,i) == a_state:
										s2 = setBefore(bflip,i)
										phase = (-1)**(s1+s2)
										K[a,b] += h[i,j]*phase
		# go to next N-particle sector
		index += dimN

	"""
	Construct part of K_ab due to .5*\sum_ij(Delta_ij a_i^\dagger a_j^\dagger - Delta_ij a_i a_j)
	Delta can couple states to those that differ by pairs.
	i.e. couples 0 particle sector to 2 particle sector, couples 4 particle sector to 6 particle sector and 2 particle sector
	For each state a, loop over all allowed states b.  Build matrix elements K_ab
	"""
	for N in range(ns+1):
		#print N
		indA = Nsectors[N][1]; dimA = Nsectors[N][0]

		"""
		If N < 2, then the K_ab can only be connected by destroying a pair. 
		"""
		if N < 2:
			#print N
			dimB = Nsectors[N+2][0]; indB = Nsectors[N+2][1]
			#print dimB; print indB
			for a in range(indA,indA+dimA):
			 	a_state = states[a]
				for b in range(indB,indB+dimB):
					b_state = states[b]
					for j in range(ns):
						if isOne(b_state,j):
							s1 = setBefore(b_state,j)
							bflip = toggleBit(b_state,j)
							for i in range(ns):
								if isOne(bflip,i):
									if toggleBit(bflip,i) == a_state:
										s2 = setBefore(bflip,i)
										phase = (-1)**(s1+s2)
										K[a,b] += (-1.)*.5*Delta[i,j]*phase
		elif N > 1 and N < ns-1:
			"""
			Otherwise, if 1 < N < ns-1, pair creation and annihilation connects the A sector to two distinct B sectors.
			B_plus : N_B = N_A + 2.  Connected by destroying a pair.
			B_minus : N_B = N_A - 2.  Connected by creating a pair.
			"""
			dimBplus = Nsectors[N+2][0]; indBplus = Nsectors[N+2][1]
			dimBminus = Nsectors[N-2][0]; indBminus = Nsectors[N-2][1]
			for a in range(indA,indA+dimA):
				a_state = states[a]
				for b in range(indBplus,indBplus+dimBplus):
					b_state = states[b]
					for j in range(ns):
						if isOne(b_state,j):
							s1 = setBefore(b_state,j)
							bflip = toggleBit(b_state,j)
							for i in range(ns):
								if isOne(bflip,i):
									if toggleBit(bflip,i) == a_state:
										s2 = setBefore(bflip,i)
										phase = (-1)**(s1+s2)
										K[a,b] += (-1.)*.5*Delta[i,j]*phase
				for b in range(indBminus,indBminus+dimBminus):
					b_state = states[b]
					for j in range(ns):
						if not isOne(b_state,j):
							s1 = setBefore(b_state,j)
							bflip = toggleBit(b_state,j)
							for i in range(ns):
								if not isOne(bflip,i):
									if toggleBit(bflip,i) == a_state:
										s2 = setBefore(bflip,i)
										phase = (-1)**(s1+s2)
										K[a,b] += .5*Delta[i,j]*phase

		elif N > ns-2:
			"""
			Finally, if N > ns-2, then the only connection is between the N and N-2 sectors.
			Only pair creating can connect these two
			"""
			dimB = Nsectors[N-2][0]; indB = Nsectors[N-2][1]
			for a in range(indA,indA+dimA):
				a_state = states[a]
				for b in range(indB,indB+dimB):
					b_state = states[b]
					for j in range(ns):
						if not isOne(b_state,j):
							s1 = setBefore(b_state,j)
							bflip = toggleBit(b_state,j)
							for i in range(ns):
								if not isOne(bflip,i):
									if toggleBit(bflip,i) == a_state:
										s2 = setBefore(bflip,i)
										phase = (-1)**(s1+s2)
										K[a,b] += .5*Delta[i,j]*phase
	#print np.trace(h); sys.exit()
	return K, np.trace(h)
							


# Calculates HFB Fermi-Dirac occupations
def calcf(beta,ek,f):
	for k in range(0,len(ek)):
		f[k] = 1./(1.+np.exp(beta*ek[k]))

# Grand-canonical HFB partition function for given beta
# Also returns contribution to <v>
def hfbpart(beta,ek):
	ns = len(ek)
	f = np.zeros(ns)
	calcf(beta,ek,f)
	lnZ = 0.
	for k in range(0,ns):
		lnZ = lnZ + np.log(2*np.cosh(beta*ek[k]/2.))
	vterm = sum(ek*f) - .5*sum(ek)
	return lnZ,vterm



def projection(beta,N,Nop,K,ns):
	lnzn = np.zeros(ns,np.complex128)
	D = la.expm(-beta*K)
	for n in range(ns):
		phin = 2*np.pi*n/float(ns)
		Gn = la.expm(1j*phin*Nop)
		eC = np.dot(Gn,D)
		lnzn[n] = np.log(np.trace(eC))

	# Prevent numerical overflow
	lnzn_avg = sum(lnzn)/float(ns)
	lnzn[:] = lnzn[:] - lnzn_avg
	C = 0.	
	for n in range(ns):
		phin = 2*np.pi*n/float(ns)
		C += np.exp(-1j*phin*N)*np.exp(lnzn[n])

	
	lnZ = float(np.log(C) + lnzn_avg - np.log(ns))
	'''
	outfile = 'lnzm-brute.dat'
	with open(outfile,'w') as f:
		for n in range(ns):
			f.write(str(np.exp(lnzn[n] + lnzn_avg)) + '\n')
		f.write(str(lnZ))
	'''
	
	return lnZ

"""
Main code
"""
start_time = time.time()
print 'Explicit'
# Read in beta (inverse temperature) values
infile = sys.argv[1]
nump = -1.
numn = -1.
betas = np.array([])
lcount = 0
with open(infile) as inf:
	for line in inf:
		if lcount == 0:
			prefix = str(line.split()[-1])
			lcount += 1
		if line.find('Proton') >= 0:
			nump = int(line.split()[-1])
			nsp = int(line.split()[-2])
			continue
		if line.find('Neutron') >= 1:
			numn = int(line.split()[-1])
			nsn = int(line.split()[-2])
			continue
		s = line.strip()
		if s[0] != '#':
			betas = np.append(betas,float(line))
if nump < 0:
	raise RuntimeError('Proton number less than 0!')
if numn < 0:
	raise RuntimeError('Neutron number less than 0!')

betas.sort()

# Find ground state energy
e0 = gndstate(prefix)
if e0 == -1:
	warnings.warn('Ground state energy not found!')


"""
This code assumes that the protons and neutrons are in the same j-shell
"""
# single j-shell
j = float((nsp-1))/2.

# dimension of single-particle-space
ns = int(2*j + 1)
#print ns
nstates = 2**ns

# many-body basis states in Slater determinant form
states = []

for k in range(nstates):
	states.append(int(k))

#for k in range(nstates):
#	print bin(states[k],ns)

# index by particle number
index = [0]*nstates

ind = 0
for num in range(ns+1):
	for k in range(nstates):
		if bitCount(states[k]) == num:
			index[k] = ind
			ind += 1

# Sort states in order of increasing particle number
oldstates = states[:]
for i in range(nstates):
	states[index[i]] = oldstates[i]

numbers = np.array([])
for i in range(nstates):
	numbers = np.append(numbers,bitCount(states[i]))

# Find dimensions of particle sectors
Nsectors = {}
k = 0
for num in range(ns+1):
	key = num
	count = 0
	while bitCount(states[k]) == num:
		count += 1
		k += 1
		if k == nstates:
			break
	Nsectors[key] = [count,k-count]
#	print Nsectors[key]
#sys.exit()
#Nvals = Nsectors.keys()
#numsecs = len(Nvals)
#print Nvals; sys.exit()

# Constructor number operator. Diagonal in the harmonic oscillator basis
Nop = np.diag(numbers)

lnZ = np.zeros(len(betas))
egc = np.zeros(len(betas))
lnZhfb = np.zeros(len(betas))

nsp = ns; nsn = ns;
for i in range(len(betas)):
	beta = betas[i]

	# Read in data from HFB files
	ep,en,up,vp,un,vn,egc[i],chmp,chmn = hfbinput(beta,prefix) 

	# Put U and V in matrix form
	upmat = np.zeros((nsp,nsp))
	vpmat = np.zeros((nsp,nsp))
	unmat = np.zeros((nsn,nsn))
	vnmat = np.zeros((nsn,nsn))

	
	# ASSUME THAT U AND V ARE PURELY REAL.  MUST BE MODIFIED IF THIS IS NOT THE CASE.
	
	
	# Construct the matrix operator K = H_HFB - mu*N for protons and neutrons
	u0termp,trhp,lnZhfbp,lnZp = 0,0,0,0
	u0termn,trhn,lnZhfbn,lnZn = 0,0,0,0
	if nump > 0:
		index = 0
		for k in range(0,nsp):
			for l in range(0,nsp):
				upmat[k,l] = up[index]
				vpmat[k,l] = vp[index]
				index = index + 1
		Wp = np.zeros((2*nsp,2*nsp))
		Wp[0:nsp,0:nsp] = upmat
		Wp[nsp:2*nsp,0:nsp] = vpmat
		Wp[0:nsp,nsp:2*nsp] = vpmat
		Wp[nsp:2*nsp,nsp:2*nsp] = upmat

		# Projection
		Kp,trhp = hamiltonian(states,ep,Wp,Nsectors)
		lnZhfbp, u0termp = hfbpart(beta,ep)
		lnZp = projection(beta,nump,Nop,Kp,nsp)
	if numn > 0:

	
		index = 0
		for k in range(0,nsn):
			for l in range(0,nsn):
				unmat[k,l] = un[index]
				vnmat[k,l] = vn[index]
				index = index + 1
		Wn = np.zeros((2*nsn,2*nsn))
		Wn[0:nsn,0:nsn] = unmat
		Wn[nsn:2*nsn,0:nsn] = vnmat
		Wn[0:nsn,nsn:2*nsn] = vnmat
		Wn[nsn:2*nsn,nsn:2*nsn] = unmat
		# Projection
		Kn,trhn = hamiltonian(states,en,Wn,Nsectors)
		lnZhfbn,u0termn = hfbpart(beta,en)
		lnZn = projection(beta,numn,Nop,Kn,nsn)

	# Grand-canonical HFB.  Determine U_0 = tr(h-mu)/2 - <V>
	u0 = egc[i] - u0termp - u0termn - chmp*nump - chmn*numn
	# determine v
	v_avg = .5*(trhp+trhn) - u0
	lnZhfb[i] = lnZhfbp + lnZhfbn - beta*u0
	lnZ[i] = lnZp + lnZn + beta*(v_avg - chmp*nump - chmn*numn)
	


EN = -numDerivative(betas,lnZ)
# Output data
twoj = int(2*j); twoj = str(twoj)
outfile = 'j' + twoj + '_wm3_ss_explicit.dat'
with open(outfile,'w') as f:
	f.write('# Explicit projection \n')
	f.write('# Np = ' + str(nump) + ' \n')
	f.write('# Nn = ' + str(numn) + ' \n')
	f.write(('# %12.6s'  + ' %12.6s'*3 + '\n') %('betas','E_N','E_gc','lnZ'))
	for i in range(0,len(betas)):
		f.write( ('%14.8E '*4 + ' \n') % (betas[i],EN[i],egc[i],lnZ[i]))

run_time = time.time() - start_time
print 'time = ', run_time,' seconds'
sys.exit()




echo 'Exact diagonalization'
python seniority.5.py > canonicalenergies.out
python Ec_exact.py > exactthermal.out

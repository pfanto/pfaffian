import sys,pdb
import numpy as np
import numpy.linalg as la

"""
Exact diagonalization of single-shell model with cranking.
Author: G.F. Bertsch.  
Restriction to to four-particle states done by P. Fanto
Last updated: 8/7/2017
Required packages: numpy, pdb
Usage: python seniority.5.py
Outputs: Energies of four-particle states.
"""
om = 4      # number of orbitals with jz > 0; for j=7/2, om=4
Nd = 2**(2*om)   #  dimension of Fock space
jz_table = []
jmax = om-0.5
for k in range(2*om):
   jz_table.append(jmax-k)
#print 'jz table:', jz_table    # for om = 4, jz_table = [3.5,2.5,1.5,0.5,-0.5,-1.5,-2.5,-3.5]

data = []      # data is a list of states (index,no. of particles,total jz)
               #  index packs the orbital filling by bit in binary  
               #  eg. idex = 5  is a two-particle state with jz=7/2,3/2 filled
for i in range(2**(2*om)):  
   n = 0
   jz = 0.0
   ishift = i*1
   for k in range(2*om):
     if ishift%2 == 1:
       n += 1
       jz += jz_table[k]
     ishift = ishift >> 1
   data.append([i,n,jz])
#print 'number of states', len(data)

H = np.array([[0.0]*Nd]*Nd)       # Hamiltonian matrix




omega  = -0.3

for i in range(Nd):
   H[i,i] =  data[i][2]*omega

pairs = []
for k in range(om):
  pairs.append([2**k,2**(2*om-k-1)])
#print 'paired orbitals', pairs



for config1 in range(Nd):       # added pairing interaction
  for k1 in range(om):
      idx1,idx2 = pairs[k1]
      if config1&idx1 and config1&idx2:
#       if config1&idx2 :
          config2 = config1-idx1-idx2
          for k2 in range(om):
             idx3,idx4 = pairs[k2]
             if config2&idx3 ==0 and config2&idx4 == 0:
               config3 = config2 + idx3 + idx4
               H[config1,config3] += -1.0


evals,evecs = la.eigh(H) 

# select energies for 4 particle states only
Nfock = 2**(2*om)
Nparticles = 4
energies = np.array([])
count = 0
for column in range(Nfock):
  for row in range(Nfock):
    if abs(evecs[row,column]) > 1e-10:
      #print data[row][1]
      if data[row][1] == Nparticles:
        energies = np.append(energies,evals[column])
      break
Nallowed = len(energies)
print "# om Nfock Nparticle N_Nparticlestates E_gs", om, Nfock, Nparticles, Nallowed,min(energies)
for i in range(Nallowed):  
  print energies[i]
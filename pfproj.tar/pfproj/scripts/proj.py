# Exact particle-number projection for finite-temperature HFB using pfaffians.
# Author: P. Fanto
# Last updated: 6/26/2017
# Required packages: numpy, pfaffian package following M. Wimmer, Algorithm 923, ACM Trans. Math. Soft. 39, 4 (2012), matplotlib
# Usage: python proj.py <file with beta values>
# Must be run from a folder with HFB data files.  Directory must also include the zero-temperature data file
# to find ground state.
# Outputs thermodynamic quantities calculated from the projected partition function.
from numpy import *
import logpfaffian as pf
import sys
import matplotlib.pyplot as plt
import warnings
import scipy.linalg as lng
import time
# Don't display warnings about casting complex values to real
warnings.filterwarnings("ignore", category=VisibleDeprecationWarning)
warnings.filterwarnings("ignore","Casting complex values")

#############################################################################
# Functions																	#
#############################################################################

# Reads in relevant data from file of the form "prefix".b"beta value".mf
# Outputs energies and U and V matrices (in list form) for p,n.
# Also outputs the quasiparticle energy and p/n chemical potentials for this beta.
def newspectrum1(beta,prefix):
	count = 0
	egc = -1.
	ep = array([])
	en = array([])
	up = array([])
	vp = array([])
	un = array([])
	vn = array([])
	jzp = -1.; jzn = -1.
	chmp = -1.
	chmn = -1.

	# Format filename
	strbeta = '{0:4.7f}'.format(beta)
	if int(strbeta[-1]) == 5:
		x = int(strbeta[-2])
		if x > 5:
			x = x + 1
		strbeta = strbeta[:-2] + str(x)
	else:
		strbeta = strbeta[:-1]
	if int(strbeta[0]) == 0:
		strbeta = strbeta[1:]
	filename = prefix +'.b'+ strbeta + '.mf'

	# Find relevant sections in data file and extract data
	with open(filename) as f:
		for line in f:
			if line.find('HFB: zero-temperature') >= 1:
				data = next(f,None)
				e0 = float(data.split()[3])
			if line.find('Quasiparticle eigenenergies in HFB hamiltonian') >= 0:
				while True:
					data = next(f,None)
					if data is None:
						break
					sp = data.split()
					if data.find('Transformation') >= 0:
						break
					if data.find('Single Particle Matrices') >= 0:
						continue
					if data.find('U') == 1:
						count = count + 1
						continue
					if data.find('V') == 1:
						count = count + 1
						continue
					if data.find('Quasiparticle') >= 0:
						count = count + 1
						continue
					if count == 0:
						for i in range(0,len(sp)):
							ep = append(ep,float(sp[i]))
					elif count == 1:
						for i in range(0,len(sp)):
							en = append(en,float(sp[i]))
					elif count == 2:
						up = append(up,float(sp[len(sp)-1]))
					elif count == 3:
						vp = append(vp,float(sp[len(sp)-1]))
					elif count == 4:
						un = append(un,float(sp[len(sp)-1]))
					elif count == 5:
						vn = append(vn,float(sp[len(sp)-1]))
			if line.find('<H ') >= 1:
				egc = float(line.split()[3])
			if line.find('Chemical potential (proton ') >= 1:
				chmp = float(next(f,None))
			if line.find('Chemical potential (neutron') >= 1:
				chmn = float(next(f,None))
			if line.find('<Jz>p') >= 1:
				jzp = float(line.split()[-1])
			if line.find('<Jz>n') >= 1:
				jzn = float(line.split()[-1])
	return ep,en,up,vp,un,vn,egc,chmp,chmn,jzp,jzn

# Finds ground state energy from zero-temperature data file
def gndstate(prefix):
	e0 = -1
	filename = prefix +'.b' + '{0:4.6f}'.format(2000.) + '.mf'
	with open(filename) as f:
		for line in f:
			if line.find('<H ') >= 1:
				e0 = float(line.split()[3])
	return e0

# Numerical derivative. Includes endpoints.
def numDerivative(x,y):
	if len(x) != len(y):
		sys.stderr.write('Error: Derivative variables have unequal length')
		sys.exit(1)
	f = zeros(len(y))
	for i in range(0,len(y)-1):
		if i == 0:
			dx = x[1]-x[0]
			dy = y[1]-y[0]
			f[i] = dy/dx
		else:
			dx = x[i+1] - x[i-1]
			dy = y[i+1]-y[i-1]
			f[i] = dy/dx
	f[-1] = (y[-1]-y[-2])/(x[-1]-x[-2])
	return f

# Calculates HFB Fermi-Dirac occupations
def calcf(beta,ek,f):
	for k in range(0,len(ek)):
		f[k] = 1./(1.+exp(beta*ek[k]))

# Grand-canonical HFB partition function for given beta
# Also returns contribution to <v>
def hfbpart(beta,ek):
	ns = len(ek)
	f = zeros(ns)
	calcf(beta,ek,f)
	lnZ = 0.
	ent = 0.
	for k in range(0,ns):
		lnZ = lnZ + log(2*cosh(beta*ek[k]/2.))
		ent += -f[k]*log(f[k]) - (1.-f[k])*log(1.-f[k])
	vterm = sum(ek*f) - .5*sum(ek)
	return lnZ,vterm,ent

# General particle-number projection using pfaffian method.
def epnp(beta,ek,umtx,vmtx,N):
	#umtx = umtx*(1+0j); vmtx = vmtx*(1+0j)
	tol = 1e-7
	
	ns = len(ek) # number of single-particle states
	iden = identity(ns)
	sigma = zeros((2*ns,2*ns))
	sigma[0:ns,ns:2*ns] = iden; sigma[ns:2*ns,0:ns] = iden
	
	"""
	Create Bogolioubov transformation matrix 
	"""
	W = zeros((2*ns,2*ns),complex128)
	W[0:ns,0:ns] = umtx; W[ns:2*ns,ns:2*ns] = umtx
	W[ns:2*ns,0:ns] = vmtx; W[0:ns,ns:2*ns] = vmtx
	Wdagger = W.T

	"""
	Create matrix D ~ e^(-beta*E)
	"""
	epsdiag = zeros(2*ns)
	epsdiag[0:ns] = exp(-beta*ek); epsdiag[ns:2*ns] = exp(beta*ek)
	#Eps = diag(-beta*epsdiag)
	D0 = diag(epsdiag)
	Dmtx = dot(dot(W,D0),Wdagger)
	#Hmtx = dot(dot(W,Eps),Wdagger)
	#Dmtx = lng.expm(Hmtx)

	"""
	Check whether in paired (HFB) or unpaired (HF) phase
	"""
	ishf = True
	truncate = array([])
	vtv = dot(vmtx.T,vmtx)
	vsq, Ct = lng.eigh(vtv)
	Nocc = 0
	for k in range(len(vsq)):
		if abs(vsq[k] - 1) > tol:
			if abs(vsq[k]) > tol:
				ishf = False
		if abs(vsq[k]) < tol:
			truncate = append(truncate,k)
		if abs(vsq[k] - 1) < tol:
			Nocc += 1
	# grand-canonical HFB Hamiltonian
	lnzhfb = 0
	for k in range(0,ns):
		lnzhfb += log(2*cosh(beta*ek[k]/2.))
	lnzm = zeros(ns,complex128) #log(zeta_n)

	# Projection loop
	for n in range(0,ns):
		if n == 0:
			lnzm[n] = lnzhfb
		else:
			"""
			Construct number matrix G ~ e^i phi N
			"""
			phin = 2*pi*n/float(ns); iphin = 1.0j*phin
			iphinarray = iphin*ones(ns)
			ndiag = concatenate((exp(iphinarray),exp(-iphinarray)))
			Gmtx = diag(ndiag) # e ^ i*phi*N

			"""
			Construct matrix T
			"""
			Tmtx = dot(Gmtx,Dmtx)  # T = (T11 T12/ T21 T22)
			T12 = Tmtx[0:ns,ns:2*ns]
			T21 = Tmtx[ns:2*ns,0:ns]
			T22 = Tmtx[ns:2*ns,ns:2*ns]

			"""
			Stably compute log(det T22)
			"""
			Qphi,Rphi = linalg.qr(T22)
			Dphi = zeros(ns,complex128)
			for k in range(0,ns):
				Dphi[k] = Rphi[k,k]
				Rphi[k,:] = Rphi[k,:]/Rphi[k,k]
			lq = linalg.eigvals(Qphi)
			lr = linalg.eigvals(Rphi)
			lndetT22 = 0. + 0j
			for k in range(0,ns):
				lndetT22 += log(lq[k]) + log(lr[k]) + log(Dphi[k])

			"""
			Construct matrix for pfaffian (see Eq. 14 of main text)
			"""
			M11 = dot(T12,lng.inv(T22))
			M22 = dot(T21,T22.T)
			M21 = identity(ns) + T22
			M12 = -M21.T
			
			M = zeros((2*ns,2*ns),complex128)
			M[0:ns,0:ns] = M11; M[0:ns,ns:2*ns] = M12
			M[ns:2*ns,0:ns] = M21; M[ns:2*ns,ns:2*ns] = M22
		
			"""
			Compute pfaffian
			"""
			lnpfm = pf.lnpfaffian_LTL(M) 

			
			"""
			Compute phase term delta
			"""
			delta = pi*n - .5*imag(lndetT22)

			"""
			Compute log(zeta_n)
			"""

			lnzm[n] = lnpfm - .5*lndetT22 + 1j*pi*(n+ns/2.) + 1j*delta
	"""
	Projected log of partition function.  Average subtracted to avoid overflow
	"""
	lnzm_avg = sum(lnzm)/ns
	lnzm_red = zeros(ns,complex128)

	# subtract average to avoid numerical overflow
	lnzm_red[:] = lnzm[:] - lnzm_avg 
	C = 0.
	for n in range(0,ns):
		iphin = 2*pi*1j*n/float(ns)
		C = C + exp(-iphin*N)*exp(lnzm[n])

	lnZ0 = float(log(C) - log(ns))
	return lnZ0

#############################################################################
# Main Code		
# This code can be used for any number of protons and neutrons.															#
#############################################################################
start_time = time.time()
print 'Pfaffian'
# Read in beta values, model space dimension, and particle numbers. Sort to be in order of increasing beta.

infile = sys.argv[1]
nump = -1. # proton number
numn = -1. # neutron number
betas = array([])
lcount = 0
with open(infile) as inf:
	for line in inf:
		if lcount == 0:
			prefix = str(line.split()[-1])
			lcount += 1
		if line.find('Proton') >= 0:
			nump = int(line.split()[-1])
			nsp = int(line.split()[-2]) # nsp(n) = proton (neutron) model space dimension
			continue
		if line.find('Neutron') >= 1:
			numn = int(line.split()[-1])
			nsn = int(line.split()[-2])
			continue
		s = line.strip()
		if s[0] != '#':
			betas = append(betas,float(line))
if nump < 0:
	raise RuntimeError('Proton number less than 0!')
if numn < 0:
	raise RuntimeError('Neutron number less than 0!')

betas.sort()

# Find ground state energy
e0 = gndstate(prefix)
if e0 == -1:
	warnings.warn('Ground state energy not found!')

"""
lnZ = number-projected partition function, pfaffian method
egc = grand-canonical HFB average energy
sgc = grand-canonical HFB entropy
Jz = grand-canonical expectation value of J_z operator
"""
lnZ = zeros(len(betas))
lnZcheck = zeros(len(betas))
Jz = zeros(len(betas))
egc = zeros(len(betas))

# Calculate projected partition function at each value of beta.  Proceed in order of increasing beta.
for i in range(0,len(betas)):
	#test0 = time.time()
	beta = betas[i]
	# read in required quantities from input file
	epr,enu,up,vp,un,vn,egc[i],chmp,chmn,jzp,jzn = newspectrum1(beta,prefix) # Read in data from HFB files
	# get expectation value of Jz
	Jz[i] = jzp + jzn

	# Put U and V in matrix form.  ASSUMED REAL, MUST BE CHANGED IF COMPLEX.
	upmat = zeros((nsp,nsp))
	vpmat = zeros((nsp,nsp))
	unmat = zeros((nsn,nsn))
	vnmat = zeros((nsn,nsn))
	

	# Grand-canonical HFB.  Determine U_0 = tr(h-mu)/2 - <V>
	lnZhfbp,u0termp,entp = 0,0,0
	lnZ0p = 0

	lnZhfbn,u0termn,entn = 0,0,0
	lnZ0n = 0

	if nump > 0:
		index = 0
		for k in range(0,nsp):
			for l in range(0,nsp):
				upmat[k,l] = up[index]
				vpmat[k,l] = vp[index]
				index = index + 1
		lnZhfbp, u0termp, entp = hfbpart(beta,epr)
		lnZ0p = epnp(beta,epr,upmat,vpmat,nump)
	if numn > 0:
		index = 0
		for k in range(0,nsn):
			for l in range(0,nsn):
				unmat[k,l] = un[index]
				vnmat[k,l] = vn[index]
				index = index + 1
		lnZhfbn,u0termn, entn = hfbpart(beta,enu)
		lnZ0n = epnp(beta,enu,unmat,vnmat,numn)

	
	u0 = egc[i] - u0termp - u0termn - chmp*nump - chmn*numn

	lnZ[i] = lnZ0p + lnZ0n - beta*u0 - beta*(chmp*nump +chmn*numn)
	#test1 = time.time()
	#print test1-test0, 'seconds'
	#sys.exit()
# Calculate canonical energy.

EN = -numDerivative(betas,lnZ)
#plt.plot(betas,EN,'b-'); plt.show()
#sys.exit()
outfile = 'j7_wm3_ss_pf.dat'
with open(outfile,'w') as f:
	f.write('# j=7/2, single shell energies, w/G = 0.3 \n')
	f.write('# Np = ' + str(nump) + ' \n')
	f.write('# Nn = ' + str(numn) + ' \n')
	f.write(('# %12.6s'  + ' %12.6s'*3 + '\n') %('betas','E_N','E_gc','lnZN'))
	for i in range(0,len(betas)):
		f.write( ('%14.8E '*4 + ' \n') % (betas[i],EN[i],egc[i],lnZ[i]))

run_time = time.time() - start_time
print 'time = ',run_time,' seconds'
sys.exit()
import sys,pdb
import numpy as np
"""
Calculates partition function and thermal energy from exact diagonalization results.
Author: P. Fanto
Last updated: 8/7/2017
"""
evals = np.loadtxt('canonicalenergies.out')
Nd = np.shape(evals)[0]
#print np.shape(evals)
#print Nd

betafile = 'j7_wm3_ss.in'
betas = np.array([])
with open(betafile) as f:
	for line in f:
		s = line.strip()
		if len(s) > 0 and s[0] != '#':
			betas = np.append(betas,float(line.split()[0]))
betas.sort()
print '# Exact energy '
print '# beta  E   lnZ '
for beta in betas:
  s0 = 0.0
  s1 = 0.0
  for i in range(Nd):
    eb = evals[i]*beta
    p = np.e**(-eb)
    s0 += p # partition function
    s1 += evals[i]*p # energy
  print beta, s1/s0, np.log(s0)

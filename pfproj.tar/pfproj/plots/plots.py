import numpy as np
import sys
import matplotlib.pyplot as plt

"""
Author: Paul Fanto
Makes plots of data
Dependencies: numpy, matplotlib
Usage: python plots.py <2j value>
Last updated: 6/27/2017
"""
twoj = int(sys.argv[1])
prefix = 'j' + str(twoj) + '_wm3_ss_'; suffix = '.dat'
#inf1 = 'j' + str(j) + '_wm3_ss_explicit.dat'
inf1 = prefix + 'explicit' + suffix
b1 = np.array([])
e1 = np.array([])
lnz1 = np.array([])
with open(inf1) as f:
	for line in f:
		s = line.strip()
		if len(s) != 0 and s[0] != '#':
			sp = line.split()
			b1 = np.append(b1,float(sp[0]))
			e1 = np.append(e1,float(sp[1]))
			lnz1 = np.append(lnz1,float(sp[3]))

#inf2 = 'pp7-wm3-ss-pf.dat'
inf2 = prefix + 'pf' + suffix
b2 = np.array([])
e2 = np.array([])
egc = np.array([])
lnz2 = np.array([])
with open(inf2) as f:
	for line in f:
		s = line.strip()
		if len(s) != 0 and s[0] != '#':
			sp = line.split()
			b2 = np.append(b2,float(sp[0]))
			e2 = np.append(e2,float(sp[1]))
			egc = np.append(egc,float(sp[2]))
			lnz2 = np.append(lnz2,float(sp[3]))

plt.figure(1)
plt.plot(b1,e1,'k-',label = 'Explicit projection')
plt.plot(b2,e2,'r--',label = 'Pfaffian')
plt.plot(b2,egc,'b-.',label = 'Grand canonical')
plt.xlabel(r'$\beta G$')
plt.ylabel(r'$E/G$')

figsuf = 'j' + str(twoj) + '-2-wm3-ss.pdf'
plt.savefig('E-' + figsuf)
#plt.title(r'Energy comparison: $\omega/G = 0.3$')
#plt.legend(loc = 0)

plt.figure(2)
plt.plot(b1,abs(e1-e2),'bo')
plt.xlabel(r'$\beta G$')
plt.ylabel(r'$\Delta E$ (MeV)')
plt.title('Absolute difference, energy')
plt.savefig('dE-'+figsuf)

plt.figure(3)
plt.plot(b1,lnz1,'k-',label = 'Explicit projection' )
plt.plot(b1,lnz2,'r--',label = 'Pfaffian')
plt.xlabel(r'$\beta G$')
plt.ylabel(r'$\ln Z$')
#plt.legend(loc = 0)
plt.savefig('lnz-'+figsuf)

plt.figure(4)
plt.plot(b1,abs(lnz1-lnz2),'bo')
plt.xlabel(r'$\beta G$')
plt.ylabel(r'$\Delta \ln Z$')
plt.title(r'Absolute difference, $lnZ$')
plt.savefig('dlnz-'+figsuf)
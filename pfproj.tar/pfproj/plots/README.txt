This directory contains a Python code to make the plots shown in the main text,
as well as additional plots showing the absolute difference between the explicit
projection results and the Pfaffian formula results, e.g. |E_pf - E_exp| as a function
of beta.

To make all plots, run

sh plot_j7.sh


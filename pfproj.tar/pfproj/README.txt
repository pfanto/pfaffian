Supplemental Material repository
Paul Fanto
paul.fanto@yale.edu

This Supplemental Material repository contains the codes and data files necessary 
to carry out the particle-number projection in the single j-shell model described
in the main text.

scripts/: This directory contains the Python codes to use the Pfaffian formula. 
and to do the projection explicitly in the many-particle space.  It also includes a code for 
the exact diagonalization of the model described in the text.

plots/: This directory contains a Python code to plot the results of the Pfaffian
formula against those of the explicit projection and of exact diagonalization.

Direct any questions to the email address listed above.